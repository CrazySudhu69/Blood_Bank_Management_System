<?php
// ✅ STOCK ALERTS WITH DONOR LINKING - Jumps to filtered view_donors.php
$host = 'localhost';
$dbname = 'blood_bank';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

// Get ALL blood groups with donor counts (for donor-based alerts)
$all_blood_groups = $pdo->query("
    SELECT blood_group, 
           COUNT(*) as total_donors,
           SUM(available = 1) as available_donors
    FROM donors 
    GROUP BY blood_group 
    ORDER BY blood_group
")->fetchAll();

// Check if blood_stock exists for hybrid mode
$has_stock_table = $pdo->query("SHOW TABLES LIKE 'blood_stock'")->rowCount() > 0;

// Categorize ALL blood groups based on donor availability
$critical = []; $low_stock = []; $healthy = [];

foreach ($all_blood_groups as $bg) {
    $available = $bg['available_donors'];
    $total = $bg['total_donors'];
    
    if ($available < 3) {
        $critical[] = $bg;
    } elseif ($available <= 10) {
        $low_stock[] = $bg;
    } else {
        $healthy[] = $bg;
    }
}

// Overall stats
$totalDonors = $pdo->query("SELECT COUNT(*) FROM donors")->fetchColumn();
$availableDonors = $pdo->query("SELECT COUNT(*) FROM donors WHERE available = 1")->fetchColumn();
$totalUnits = $has_stock_table ? $pdo->query("SELECT SUM(units) FROM blood_stock")->fetchColumn() ?? 0 : 0;
?>

<!DOCTYPE html>
<html>
<head>
    <title>Blood Stock Alerts - Find Donors</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { 
            background: linear-gradient(135deg, #ff416c, #ff4b2b); 
            min-height: 100vh; 
        }
        .glass { 
            background: rgba(255,255,255,0.95); 
            backdrop-filter: blur(12px); 
            border-radius: 16px; 
            box-shadow: 0 12px 40px rgba(0,0,0,0.15); 
        }
        .alert-card { 
            border-left: 6px solid; 
            transition: all 0.3s; 
        }
        .alert-card:hover { 
            transform: translateY(-4px); 
            box-shadow: 0 20px 40px rgba(0,0,0,0.2) !important;
        }
        .critical { border-left-color: #dc3545; }
        .warning { border-left-color: #ffc107; }
        .success { border-left-color: #28a745; }
        .count-badge { 
            font-size: 1.5rem; 
            font-weight: bold; 
            min-width: 60px; 
        }
        .stats-card {
            background: rgba(255,255,255,0.2);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.3);
        }
        .donor-link {
            position: relative;
            overflow: hidden;
        }
        .donor-link::after {
            content: '→ View Donors';
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            font-size: 0.85rem;
            opacity: 0;
            transition: all 0.3s;
        }
        .donor-link:hover::after {
            opacity: 1;
            right: 10px;
        }
    </style>
</head>
<body>
    <nav class="navbar navbar-expand navbar-dark bg-danger shadow-lg mb-4">
        <div class="container">
            <a class="navbar-brand fs-3"><i class="fas fa-tint"></i> Blood Bank Alerts</a>
            <div class="navbar-nav ms-auto">
                <a href="dashboard.php" class="nav-link">Dashboard</a>
                <a href="add_donor.php" class="nav-link">Add Donor</a>
                <a href="view_donors.php" class="nav-link">All Donors</a>
            </div>
        </div>
    </nav>

    <div class="container py-5">
        <!-- Stats Overview -->
        <div class="row mb-5">
            <div class="col-md-3 mb-3">
                <div class="stats-card glass p-4 text-center text-white">
                    <i class="fas fa-users fa-3x mb-3 opacity-75"></i>
                    <h3 class="fw-bold"><?php echo $totalDonors; ?></h3>
                    <p class="mb-0">Total Donors</p>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="stats-card glass p-4 text-center text-white">
                    <i class="fas fa-user-check fa-3x mb-3 opacity-75"></i>
                    <h3 class="fw-bold"><?php echo $availableDonors; ?></h3>
                    <p class="mb-0">Available Now</p>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="stats-card glass p-4 text-center text-white">
                    <i class="fas fa-vials fa-3x mb-3 opacity-75"></i>
                    <h3 class="fw-bold"><?php echo $totalUnits; ?></h3>
                    <p class="mb-0">Total Units</p>
                </div>
            </div>
            <div class="col-md-3 mb-3">
                <div class="stats-card glass p-4 text-center text-white">
                    <i class="fas fa-tint fa-3x mb-3 opacity-75"></i>
                    <h3 class="fw-bold"><?php echo count($all_blood_groups); ?></h3>
                    <p class="mb-0">Blood Groups</p>
                </div>
            </div>
        </div>

        <div class="row mb-5">
            <div class="col text-center">
                <h1 class="display-4 fw-bold text-white mb-3">🚨 Donor Availability</h1>
                <p class="lead text-white-50">Click any blood group to view available donors instantly</p>
            </div>
        </div>

        <!-- CRITICAL - Urgent Action Required -->
        <?php if ($critical): ?>
        <div class="row g-4 mb-5">
            <div class="col-12">
                <h3 class="text-danger mb-4">
                    <i class="fas fa-exclamation-triangle fa-2x"></i>
                    URGENT: Critical Shortage
                    <span class="badge bg-danger ms-2 fs-6"><?php echo count($critical); ?> Groups</span>
                </h3>
            </div>
            <?php foreach ($critical as $alert): ?>
            <div class="col-md-6 col-lg-4">
                <a href="view_donors.php?blood=<?php echo urlencode($alert['blood_group']); ?>" 
                   class="donor-link text-decoration-none">
                    <div class="glass p-4 h-100 alert-card critical">
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-danger text-white rounded-circle p-3 me-3">
                                <i class="fas fa-exclamation-circle fa-2x"></i>
                            </div>
                            <div class="flex-grow-1">
                                <h4 class="mb-1"><?php echo $alert['blood_group']; ?></h4>
                                <div class="d-flex align-items-center gap-2">
                                    <span class="count-badge text-danger"><?php echo $alert['available_donors']; ?></span>
                                    <small class="text-muted">Available</small>
                                    <span class="badge bg-danger">CRITICAL</span>
                                </div>
                                <small class="text-muted d-block">(<?php echo $alert['total_donors']; ?> total)</small>
                            </div>
                        </div>
                        <p class="mb-0 text-danger fw-bold">
                            ⚠️ Immediate donor recruitment needed!
                        </p>
                    </div>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- LOW STOCK - Plan Ahead -->
        <?php if ($low_stock): ?>
        <div class="row g-4 mb-5">
            <div class="col-12">
                <h3 class="text-warning mb-4">
                    <i class="fas fa-exclamation-triangle fa-2x"></i>
                    ⚠️ Low Availability
                    <span class="badge bg-warning text-dark ms-2 fs-6"><?php echo count($low_stock); ?> Groups</span>
                </h3>
            </div>
            <?php foreach ($low_stock as $alert): ?>
            <div class="col-md-6 col-lg-4">
                <a href="view_donors.php?blood=<?php echo urlencode($alert['blood_group']); ?>" 
                   class="donor-link text-decoration-none">
                    <div class="glass p-4 h-100 alert-card warning">
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-warning text-dark rounded-circle p-3 me-3">
                                <i class="fas fa-exclamation-triangle fa-2x"></i>
                            </div>
                            <div class="flex-grow-1">
                                <h4 class="mb-1"><?php echo $alert['blood_group']; ?></h4>
                                <div class="d-flex align-items-center gap-2">
                                    <span class="count-badge text-warning"><?php echo $alert['available_donors']; ?></span>
                                    <small class="text-muted">Available</small>
                                    <span class="badge bg-warning text-dark">LOW</span>
                                </div>
                                <small class="text-muted d-block">(<?php echo $alert['total_donors']; ?> total)</small>
                            </div>
                        </div>
                        <p class="mb-0 text-warning fw-semibold">
                            📅 Plan donation camp soon
                        </p>
                    </div>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <!-- HEALTHY STOCK - Good Status -->
        <?php if ($healthy): ?>
        <div class="row g-4 mb-5">
            <div class="col-12">
                <h3 class="text-success mb-4">
                    <i class="fas fa-check-circle fa-2x"></i>
                    ✅ Good Availability
                    <span class="badge bg-success ms-2 fs-6"><?php echo count($healthy); ?> Groups</span>
                </h3>
            </div>
            <?php foreach ($healthy as $alert): ?>
            <div class="col-md-6 col-lg-4">
                <a href="view_donors.php?blood=<?php echo urlencode($alert['blood_group']); ?>" 
                   class="donor-link text-decoration-none">
                    <div class="glass p-4 h-100 alert-card success">
                        <div class="d-flex align-items-center mb-3">
                            <div class="bg-success text-white rounded-circle p-3 me-3">
                                <i class="fas fa-check-circle fa-2x"></i>
                            </div>
                            <div class="flex-grow-1">
                                <h4 class="mb-1"><?php echo $alert['blood_group']; ?></h4>
                                <div class="d-flex align-items-center gap-2">
                                    <span class="count-badge text-success"><?php echo $alert['available_donors']; ?></span>
                                    <small class="text-muted">Available</small>
                                    <span class="badge bg-success">GOOD</span>
                                </div>
                                <small class="text-muted d-block">(<?php echo $alert['total_donors']; ?> total)</small>
                            </div>
                        </div>
                        <p class="mb-0 text-success fw-semibold">
                            ✅ Stock levels satisfactory
                        </p>
                    </div>
                </a>
            </div>
            <?php endforeach; ?>
        </div>
        <?php endif; ?>

        <div class="text-center mt-5">
            <a href="dashboard.php" class="btn btn-outline-light btn-lg px-5 py-3 me-3">
                ← Dashboard
            </a>
            <a href="view_donors.php" class="btn btn-light btn-lg px-5 py-3">
                👥 View All Donors
            </a>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>