<?php
// add_donor.php - Add donor + update stock automatically
$host = 'localhost';
$dbname = 'blood_bank';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch(PDOException $e) {
    die("Connection failed: " . $e->getMessage());
}

$message = '';
if ($_POST) {
    $name = trim($_POST['name']);
    $phone = trim($_POST['phone']);
    $email = trim($_POST['email']);
    $blood_group = $_POST['blood_group'];
    $available = isset($_POST['available']) ? 1 : 0;

    // 1️⃣ Insert donor into donors table
    $stmt = $pdo->prepare("INSERT INTO donors (name, phone, email, blood_group, available) VALUES (?, ?, ?, ?, ?)");
    $stmt->execute([$name, $phone, $email, $blood_group, $available]);

    // 2️⃣ Update blood_stock table automatically
    // Try updating first
    $stmt2 = $pdo->prepare("UPDATE blood_stock SET units = units + 1 WHERE blood_group = ?");
    $stmt2->execute([$blood_group]);

    // If no row was updated, insert new blood group row
    if ($stmt2->rowCount() == 0) {
        $stmt3 = $pdo->prepare("INSERT INTO blood_stock (blood_group, units) VALUES (?, 1)");
        $stmt3->execute([$blood_group]);
    }

    $message = 'Donor added successfully and stock updated!';
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Add Donor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-body">
                        <h2 class="card-title text-center mb-4">➕ Add New Donor</h2>
                        <?php if ($message): ?>
                            <div class="alert alert-success"><?php echo $message; ?></div>
                            <a href="dashboard.php" class="btn btn-primary w-100 mb-3">View Dashboard</a>
                            <a href="add_donor.php" class="btn btn-secondary w-100">Add Another Donor</a>
                        <?php else: ?>
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">Full Name</label>
                                <input type="text" name="name" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Phone</label>
                                <input type="tel" name="phone" class="form-control" required>
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Email (optional)</label>
                                <input type="email" name="email" class="form-control">
                            </div>
                            <div class="mb-3">
                                <label class="form-label">Blood Group</label>
                                <select name="blood_group" class="form-select" required>
                                    <option value="A+">A+</option>
                                    <option value="B+">B+</option>
                                    <option value="AB+">AB+</option>
                                    <option value="O+">O+</option>
                                    <option value="A-">A-</option>
                                    <option value="B-">B-</option>
                                    <option value="AB-">AB-</option>
                                    <option value="O-">O-</option>
                                </select>
                            </div>
                            <div class="mb-3 form-check">
                                <input type="checkbox" name="available" class="form-check-input" id="available" checked>
                                <label class="form-check-label" for="available">Available to donate now</label>
                            </div>
                            <button type="submit" class="btn btn-danger w-100">Add Donor</button>
                        </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
