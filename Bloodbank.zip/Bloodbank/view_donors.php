<?php
// ✅ SELF-CONTAINED view_donors.php - No config.php needed
// Direct DB connection
$host = 'localhost';
$dbname = 'blood_bank';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die('Database connection failed: ' . $e->getMessage());
}

if (isset($_GET['delete'])) {
    $stmt = $pdo->prepare("DELETE FROM donors WHERE id = ?");
    $stmt->execute([ (int)$_GET['delete'] ]);
    // Preserve filter after delete
    $redirect = $_SERVER['PHP_SELF'] . (isset($_GET['blood']) ? '?blood=' . urlencode($_GET['blood']) : '');
    header('Location: ' . $redirect);
    exit;
}

// Blood group filter
$blood_filter = isset($_GET['blood']) ? trim($_GET['blood']) : '';
$filter_sql = $blood_filter ? "WHERE blood_group = ?" : "";
$params = $blood_filter ? [$blood_filter] : [];

$stmt = $pdo->prepare("SELECT * FROM donors $filter_sql ORDER BY name ASC");
$stmt->execute($params);
$donors = $stmt->fetchAll();

$title = $blood_filter ? $blood_filter . ' Donors' : 'All Donors';
$donor_count = count($donors);
$is_filtered = !empty($blood_filter);
?>

<!DOCTYPE html>
<html>
<head>
    <title><?php echo htmlspecialchars($title); ?> - Blood Bank</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style> 
        body { 
            background: linear-gradient(135deg, #ff6b6b, #feca57); 
            min-height: 100vh; 
        }
        .glass { 
            background: rgba(255,255,255,0.95); 
            backdrop-filter: blur(12px); 
            border-radius: 16px; 
            box-shadow: 0 12px 40px rgba(0,0,0,0.15); 
        }
        .donor-card {
            transition: all 0.3s ease;
        }
        .donor-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.15) !important;
        }
        .filter-badge {
            background: rgba(255,255,255,0.2);
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255,255,255,0.3);
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <!-- Header with Filter Info -->
        <div class="glass p-4 mb-4 shadow-lg">
            <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap gap-3">
                <div>
                    <h2 class="mb-1 text-dark">
                        <i class="fas fa-users text-primary me-2"></i>
                        <?php echo $is_filtered ? '<strong>' . htmlspecialchars($blood_filter) . '</strong>' : 'All'; ?> 
                        Donors 
                        <span class="badge bg-primary fs-5 ms-2"><?php echo $donor_count; ?></span>
                    </h2>
                    <?php if ($is_filtered): ?>
                    <div class="mt-1">
                        <small class="text-muted me-2">Showing donors with</small>
                        <span class="badge filter-badge text-dark px-3 py-2 rounded-pill">
                            <i class="fas fa-tint me-1"></i><?php echo htmlspecialchars($blood_filter); ?>
                        </span>
                    </div>
                    <?php endif; ?>
                </div>
                <div class="d-flex gap-2 flex-wrap">
                    <?php if ($is_filtered): ?>
                    <a href="view_donors.php" class="btn btn-outline-secondary">
                        <i class="fas fa-list-ul me-1"></i>All Donors
                    </a>
                    <?php endif; ?>
                    <a href="add_donor.php" class="btn btn-success">
                        <i class="fas fa-plus me-1"></i>Add Donor
                    </a>
                    <a href="dashboard.php" class="btn btn-outline-primary">
                        <i class="fas fa-chart-dashboard me-1"></i>Dashboard
                    </a>
                </div>
            </div>
        </div>

        <?php if (empty($donors)): ?>
        <!-- Empty State -->
        <div class="glass p-5 text-center shadow-lg">
            <div class="row align-items-center">
                <div class="col-md-6">
                    <i class="fas fa-users-slash fa-4x text-muted mb-4"></i>
                    <h3 class="text-muted mb-3">No donors found</h3>
                    <?php if ($is_filtered): ?>
                    <p class="lead text-muted mb-4">
                        No donors available with <strong><?php echo htmlspecialchars($blood_filter); ?></strong> blood group
                    </p>
                    <?php else: ?>
                    <p class="lead text-muted mb-4">Your donor database is empty</p>
                    <?php endif; ?>
                    <a href="add_donor.php<?php echo $is_filtered ? '?blood=' . urlencode($blood_filter) : ''; ?>" 
                       class="btn btn-primary btn-lg px-5">
                        <i class="fas fa-plus-circle me-2"></i>
                        <?php echo $is_filtered ? 'Add ' . $blood_filter . ' Donor' : 'Add First Donor'; ?>
                    </a>
                </div>
                <div class="col-md-6">
                    <div class="bg-light rounded-4 p-4">
                        <h6 class="text-muted mb-3">💡 Quick Tips:</h6>
                        <ul class="text-muted small mb-0">
                            <li>• Add donors with complete contact info</li>
                            <li>• Mark availability status correctly</li>
                            <li>• Use stock alerts to find urgent needs</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <?php else: ?>
        <!-- Donor List -->
        <div class="row g-4">
            <?php foreach ($donors as $donor): ?>
            <div class="col-xl-3 col-lg-4 col-md-6">
                <div class="donor-card glass p-4 h-100 shadow-lg position-relative">
                    <!-- Top Status Badge -->
                    <div class="position-absolute top-0 end-0 m-3 z-3">
                        <span class="badge fs-6 px-3 py-2 rounded-pill shadow-sm 
                            <?php echo $donor['available'] ? 'bg-success' : 'bg-secondary'; ?>">
                            <?php echo $donor['available'] ? 
                                '<i class="fas fa-check-circle me-1"></i>Available' : 
                                '<i class="fas fa-clock me-1"></i>Recent Donation'; ?>
                        </span>
                    </div>

                    <!-- Donor Info -->
                    <div class="text-center mb-3 pt-3">
                        <div class="avatar-placeholder rounded-circle mx-auto mb-3 p-4 bg-primary bg-opacity-10 border">
                            <i class="fas fa-user fa-2x text-primary"></i>
                        </div>
                        <h5 class="fw-bold text-dark mb-2">
                            <?php echo htmlspecialchars($donor['name']); ?>
                        </h5>
                        <div class="mb-3">
                            <span class="badge bg-danger fs-6 px-4 py-2 shadow-sm">
                                <i class="fas fa-tint me-1"></i><?php echo htmlspecialchars($donor['blood_group']); ?>
                            </span>
                        </div>
                    </div>

                    <!-- Contact Info -->
                    <div class="contact-info mb-4 small">
                        <div class="d-flex align-items-center mb-2 p-2 bg-light rounded-3">
                            <i class="fas fa-phone text-success me-3 fs-5"></i>
                            <span class="fw-semibold"><?php echo htmlspecialchars($donor['phone']); ?></span>
                        </div>
                        <?php if (!empty($donor['email'])): ?>
                        <div class="d-flex align-items-center p-2 bg-light rounded-3">
                            <i class="fas fa-envelope text-primary me-3 fs-5"></i>
                            <span class="text-truncate"><?php echo htmlspecialchars($donor['email']); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>

                    <!-- Action Buttons -->
                    <div class="d-flex gap-2 position-absolute bottom-0 start-50 translate-middle-x pb-3 px-3 w-100">
                        <a href="add_donor.php?id=<?php echo (int)$donor['id']; ?>" 
                           class="btn btn-outline-primary flex-fill shadow-sm">
                            <i class="fas fa-edit me-1"></i>Edit
                        </a>
                        <a href="?delete=<?php echo (int)$donor['id']; ?>
                                <?php echo $is_filtered ? '&blood=' . urlencode($blood_filter) : ''; ?>" 
                           class="btn btn-outline-danger shadow-sm"
                           onclick="return confirm('Delete <?php echo addslashes($donor['name']); ?>?\nThis cannot be undone.')"
                           title="Delete Donor">
                            <i class="fas fa-trash"></i>
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
        </div>

        <!-- Quick Stats Footer -->
        <div class="glass p-4 mt-5 text-center">
            <small class="text-muted">
                Showing <?php echo $donor_count; ?> donor<?php echo $donor_count !== 1 ? 's' : ''; ?> 
                <?php echo $is_filtered ? "for <strong>$blood_filter</strong>" : 'total'; ?>
                | <a href="stock_alerts.php" class="text-primary text-decoration-none fw-semibold">🚨 Check Stock Alerts</a>
                | <a href="add_donor.php" class="text-success text-decoration-none fw-semibold">➕ Add More Donors</a>
            </small>
        </div>
        <?php endif; ?>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>