<?php
$host = 'localhost';
$dbname = 'blood_bank';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Connection failed");
}

$total = 0;
$available = 0;

try {
    $total = $pdo->query("SELECT COUNT(*) FROM donors")->fetchColumn();
    $available = $pdo->query("SELECT COUNT(*) FROM donors WHERE available = 1")->fetchColumn();
} catch(PDOException $e) {}

$search = trim($_GET['search'] ?? '');
$blood_filter = isset($_GET['blood']) ? rawurldecode($_GET['blood']) : '';
$blood_filter = trim($blood_filter);

$where = "available = 1";
$params = [];

if ($search !== '') {
    $where .= " AND (name LIKE ? OR phone LIKE ?)";
    $params[] = "%$search%";
    $params[] = "%$search%";
}

if ($blood_filter !== '') {
    $where .= " AND blood_group = ?";
    $params[] = $blood_filter;
}

$donors = [];

try {
    $sql = "SELECT * FROM donors WHERE $where ORDER BY name ASC LIMIT 10";
    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $donors = $stmt->fetchAll();
} catch(PDOException $e) {}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Blood Bank Dashboard</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body{background:linear-gradient(135deg,#ff6b6b,#feca57);min-height:100vh}
.glass{background:rgba(255,255,255,.95);backdrop-filter:blur(10px);border-radius:20px;box-shadow:0 8px 32px rgba(0,0,0,.1)}
.blood-card{border-left:5px solid;transition:.2s}
.blood-card:hover{transform:translateY(-5px)}
.A-plus{border-left-color:#dc3545}
.B-plus{border-left-color:#fd7e14}
.AB-plus{border-left-color:#ffc107}
.O-plus{border-left-color:#198754}
.A-minus{border-left-color:#6f42c1}
.B-minus{border-left-color:#0dcaf0}
.AB-minus{border-left-color:#20c997}
.O-minus{border-left-color:#dc3545}
</style>
</head>
<body>

<div class="container py-5">
<div class="text-center mb-5">
<h1 class="display-3 fw-bold text-white">🩸 Blood Bank</h1>
<p class="text-white-50">Save Lives - Donate Blood</p>
</div>

<div class="row g-4">
<div class="col-md-4">
<div class="glass p-4 blood-card O-plus">
<h3 class="text-danger"><?php echo $total; ?></h3>
<p>Total Donors</p>
</div>
</div>

<div class="col-md-4">
<div class="glass p-4 blood-card A-plus">
<h3 class="text-danger"><?php echo $available; ?></h3>
<p>Available Now</p>
</div>
</div>

<div class="col-md-4">
<div class="glass p-4 h-100 d-flex align-items-center">
<a href="add_donor.php" class="btn btn-danger w-100">➕ Add Donor</a>
</div>
</div>
</div>

<div class="glass p-4 mt-4">
<form method="GET" class="row g-3">
<div class="col-md-5">
<input type="text" name="search" class="form-control form-control-lg"
value="<?php echo htmlspecialchars($search); ?>" placeholder="Name or Phone">
</div>

<div class="col-md-4">
<select name="blood" class="form-select form-select-lg">
<option value="">All Blood Groups</option>
<?php
$groups = ['A+','B+','AB+','O+','A-','B-','AB-','O-'];
foreach ($groups as $g) {
    $sel = $blood_filter === $g ? 'selected' : '';
    echo "<option value=\"$g\" $sel>$g</option>";
}
?>
</select>
</div>

<div class="col-md-3">
<button class="btn btn-danger w-100 h-100">Search</button>
</div>
</form>
</div>

<?php if ($donors): ?>
<div class="glass mt-4 p-4">
<h4>Available Donors (<?php echo count($donors); ?>)
<a href="stock_alerts.php" class="btn btn-danger btn-sm ms-2">🚨 Stock Alerts</a>
<a href="view_donors.php" class="btn btn-danger btn-sm ms-2">🚨 View Donors</a>
</h4>

<div class="row g-3 mt-3">
<?php foreach ($donors as $d):
$class = str_replace(['+','-'],['-plus','-minus'],$d['blood_group']);
?>
<div class="col-md-6 col-lg-4">
<div class="glass p-4 blood-card <?php echo $class; ?>">
<h5><?php echo htmlspecialchars($d['name']); ?></h5>
<span class="badge bg-danger"><?php echo $d['blood_group']; ?></span>
<p class="mt-2">📞 <?php echo $d['phone']; ?></p>
<a href="view_donors.php?id=<?php echo $d['id']; ?>" class="btn btn-outline-danger w-100">View</a>
</div>
</div>
<?php endforeach; ?>
</div>
</div>
<?php else: ?>
<div class="glass text-center p-5 mt-4">
<h5>No donors found</h5>
</div>
<?php endif; ?>

</div>
</body>
</html>
